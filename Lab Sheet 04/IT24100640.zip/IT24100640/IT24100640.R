setwd("C:\\Users\\it24100640\\Desktop\\IT24100640")
getwd()

data<-read.table("DATA 4.txt",header = TRUE,sep = " ")
fix(data)
attach(data)

boxplot(X1,main="box plot for team assistance",outline = TRUE,outpch=8,horizontal = TRUE)
hist(X1,main ="for team assistance" )

stem(X1)
mean(X1)
median(X1)
sd(X1)
summary(X1)
quantile(X1)[4]
IQR(X1)


#Exercise
# 1.import the data into a dataframe called branch_data
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)

# 2.Identify the variable type and scale of measurement for each variable.
      #Branch is a categorical variable (nominal scale) since it's just an identifier for each branch.
      #Sales_X1 is a numerical variable (ratio scale), representing sales figures. It's a continuous variable.
      #Advertising_X2 is a numerical variable (ratio scale), representing advertising spend. It's a continuous variable.
      #Years_X3 is a numerical variable (ratio scale), representing the number of years. It's a continuous variable.

# 3.Obtain boxplot for sales and interpret the shape of the sales distribution.
boxplot(branch_data$Sales_X1, main = "Boxplot for Sales", ylab = "Sales_X1")

# 4.Calculate the five number summary and IQR for advertising variable.
quantile(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#5. Write an R function to find the outliers in a numeric vector and check for outliers in years variables.
# Function to detect outliers using 1.5 * IQR rule
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in the Years_X3 variable
outliers_years <- find_outliers(branch_data$Years_X3)
outliers_years


